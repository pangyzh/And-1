package com.example.pangyzh.chronometer;

import android.app.Activity;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private Chronometer timer,Time;
    private Button start,stop,reset;
    private String stopTime="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        start = (Button)this.findViewById(R.id.button);
        stop = (Button)this.findViewById(R.id.button2);
        reset = (Button)this.findViewById(R.id.button3);
        Time = (Chronometer)this.findViewById(R.id.chronometer2);
        timer = (Chronometer)this.findViewById(R.id.chronometer3);
        start.setOnClickListener(this);
        stop.setOnClickListener(this);
        reset.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.button:
                //清零
                timer.setBase(SystemClock.elapsedRealtime());
                if(stopTime!="") Time.setFormat(stopTime);
                else Time.setBase(SystemClock.elapsedRealtime());
                //开始计时
                timer.start();
                Time.start();
                break;
            case R.id.button2:
                //停止计时
                timer.stop();
                stopTime = timer.getFormat();
                break;
            case R.id.button3:
                //计时器清零
                timer.setBase(SystemClock.elapsedRealtime());
                timer.stop();
                stopTime="";
                Time.setBase(SystemClock.elapsedRealtime());
                Time.stop();
                break;
        }
    }
}
