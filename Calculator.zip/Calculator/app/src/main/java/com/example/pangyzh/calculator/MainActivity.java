package com.example.pangyzh.calculator;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText input;
    Button clear,delete,cheng,chu,num7,num8,num9,charjian,num4,num5,num6,charadd,num1,num2,num3,num0,dian,equal;

    private  String ss="";
    private  boolean fu=false;
    private  boolean num=false;
    private  boolean point=false;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        input = (EditText)findViewById(R.id.input);
        clear = (Button)findViewById(R.id.clear);
        delete = (Button)findViewById(R.id.delete);
        cheng = (Button)findViewById(R.id.cheng);
        chu = (Button)findViewById(R.id.clu);
        num7 = (Button)findViewById(R.id.num7);
        num8 = (Button)findViewById(R.id.num8);
        num9 = (Button)findViewById(R.id.num9);
        charjian = (Button)findViewById(R.id.charjian);
        num4 = (Button)findViewById(R.id.num4);
        num5 = (Button)findViewById(R.id.num5);
        num6 = (Button)findViewById(R.id.num6);
        charadd = (Button)findViewById(R.id.charadd);
        num1 = (Button)findViewById(R.id.num1);
        num2 = (Button)findViewById(R.id.num2);
        num3 = (Button)findViewById(R.id.num3);
        num0 = (Button)findViewById(R.id.num0);
        dian = (Button)findViewById(R.id.dian);
        equal = (Button)findViewById(R.id.equai);

        input.setOnClickListener(this);
        num1.setOnClickListener(this);
        num2.setOnClickListener(this);
        num3.setOnClickListener(this);
        num4.setOnClickListener(this);
        num5.setOnClickListener(this);
        num6.setOnClickListener(this);
        num7.setOnClickListener(this);
        num8.setOnClickListener(this);
        num9.setOnClickListener(this);
        num0.setOnClickListener(this);
        dian.setOnClickListener(this);
        charadd.setOnClickListener(this);
        charjian.setOnClickListener(this);
        cheng.setOnClickListener(this);
        chu.setOnClickListener(this);
        equal.setOnClickListener(this);
        clear.setOnClickListener(this);
        delete.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.clear:
            {
                ss="";
                input.setText(ss);
            }
            break;
            case R.id.delete:
            {
                if(ss.indexOf(" ")==ss.length()-3) ss= ss.substring(0,ss.length() - 2);
                if(ss.length()>0) ss= ss.substring(0,ss.length() - 1);
                input.setText(ss);
            }
            break;
            case R.id.cheng:
            {
                if(ss.length()==0) break;
                if(ss.contains(" "))
                {
                    if(ss.indexOf(" ")==ss.length()-3||ss.indexOf(" ")==ss.length()-2||ss.indexOf(" ")==ss.length()-1) break;
                    getResult();
                }
                fu=true;
                ss+=" × ";
                input.setText(ss);
            }
            break;
            case R.id.clu:
            {
                if(ss.length()==0) break;
                if(ss.contains(" "))
                {
                    if(ss.indexOf(" ")==ss.length()-3||ss.indexOf(" ")==ss.length()-2||ss.indexOf(" ")==ss.length()-1) break;
                    getResult();
                }
                fu=true;
                ss+=" ÷ ";
                input.setText(ss);
            }
            break;
            case R.id.num7:
            {
                ss+="7";
                input.setText(ss);
            }
            break;
            case R.id.num8:
            {
                ss+="8";
                input.setText(ss);
            }
            break;
            case R.id.num9:
            {
                ss+="9";
                input.setText(ss);
            }
            break;
            case R.id.charjian:
            {
                if(ss.length()==0) break;
                if(ss.contains(" "))
                {
                    if(ss.indexOf(" ")==ss.length()-3||ss.indexOf(" ")==ss.length()-2||ss.indexOf(" ")==ss.length()-1) break;
                    getResult();
                }
                fu=true;
                ss+=" － ";
                input.setText(ss);
            }
            break;
            case R.id.num4:
            {
                ss+="4";
                input.setText(ss);
            }
            break;
            case R.id.num5:
            {
                ss+="5";
                input.setText(ss);
            }
            break;
            case R.id.num6:
            {
                ss+="6";
                input.setText(ss);
            }
            break;
            case R.id.charadd:
            {
                if(ss.length()==0) break;
                if(ss.contains(" "))
                {
                    if(ss.indexOf(" ")==ss.length()-3||ss.indexOf(" ")==ss.length()-2||ss.indexOf(" ")==ss.length()-1) break;
                    getResult();
                }
                fu=true;
                ss+=" ＋ ";
                input.setText(ss);
            }
            break;
            case R.id.num1:
            {
                ss+="1";
                input.setText(ss);
            }
            break;
            case R.id.num2:
            {
                ss+="2";
                input.setText(ss);
            }
            break;
            case R.id.num3:
            {
                ss+="3";
                input.setText(ss);
            }
            break;
            case R.id.num0:
            {
                ss+="0";
                input.setText(ss);
            }
            break;
            case R.id.dian:
            {
                if(ss.length()==0||ss.indexOf(" ")==ss.length()-3||ss.lastIndexOf(".")>ss.indexOf(" ")) break;
                else
                {
                    ss+=".";
                    input.setText(ss);
                }
            }
            break;
            case R.id.equai:
                getResult();
                break;
        }
    }
    private void getResult()
    {
        double result=0;
        if(ss==null||ss.equals("")) return;
        if(!ss.contains(" "))  return;
        String s1=ss.substring(0,ss.indexOf(" "));
        String op=ss.substring(ss.indexOf(" ")+1,ss.indexOf(" ")+2);
        String s2=ss.substring(ss.indexOf(" ")+3);
        if(!s1.equals("")&&!s2.equals(""))
        {
            double d1=Double.parseDouble(s1);
            double d2=Double.parseDouble(s2 );
            switch (op)
            {
                case "＋": result=d1+d2;break;
                case "－": result=d1-d2;break;
                case "×": result=d1*d2;break;
                case "÷":
                {
                    if(d2==0)
                    {
                        Toast.makeText(this, "不能除以零", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    result=d1/d2*1.0;
                }
                break;
            }

            int r = (int)  result;
            if(r==result)
            {
                input.setText(""+r);
                ss=""+r;
            }
            else
            {
                input.setText(result+"");
                ss=""+result;
            }
        }
    }
}
